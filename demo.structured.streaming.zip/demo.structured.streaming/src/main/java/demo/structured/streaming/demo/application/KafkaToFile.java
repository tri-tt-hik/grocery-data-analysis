package demo.structured.streaming.demo.application;

import static org.apache.spark.sql.functions.col;
import static org.apache.spark.sql.functions.from_json;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.DataStreamReader;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;
import static org.apache.spark.sql.functions.*;

public class KafkaToFile {

	public static void main(String[] args) throws StreamingQueryException {

		SparkSession spark = SparkSession.builder().master("local").appName("JavaStructuredKafkaWordCount")
				.getOrCreate();

		spark.sparkContext().setLogLevel("ERROR");

		List<StructField> fields = new ArrayList<StructField>();
		fields.add(DataTypes.createStructField("id", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("firstName", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("lastName", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("country", DataTypes.StringType, true));

		StructType structType = DataTypes.createStructType(fields);

		DataStreamReader dataStreamReader = spark.readStream();
		Dataset<Row> df = dataStreamReader.format("kafka").option("kafka.bootstrap.servers", "localhost:9092")
				.option("subscribe", "river_test").load().selectExpr("CAST(key AS STRING)", "CAST(value AS STRING)")
				.withColumn("value", from_json(col("value"), structType)).select(col("value.*"))				
				.groupBy(col("country")).count().alias("num_users");
				//.agg(count(lit(1)).alias("Num Of Records"));

		/*df.createOrReplaceTempView("user_records");
		Dataset<Row> aggUsers = spark.sql("SELECT country, COUNT(1) as num_users FROM user_records GROUP BY country");
        */
		
		
		StreamingQuery query = df.writeStream()
				.option("checkpointLocation", "/Users/s0v00ao/Desktop/Demo/checkpoint_kafka")
				.option("truncate", false)
				.outputMode("complete")
				.format("console").start();

		query.awaitTermination();

	}

}
