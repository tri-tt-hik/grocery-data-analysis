package demo.structured.streaming.demo.application;

import java.util.ArrayList;
import java.util.List;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.DataStreamReader;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

public class FileToConsole {

	public static void main(String[] args) throws StreamingQueryException {

		SparkSession spark = SparkSession.builder().master("local").appName("JavaStructuredKafkaWordCount")
				.getOrCreate();

		spark.sparkContext().setLogLevel("ERROR");

		List<StructField> fields = new ArrayList<StructField>();
		fields.add(DataTypes.createStructField("id", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("firstName", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("lastName", DataTypes.StringType, true));
		fields.add(DataTypes.createStructField("country", DataTypes.StringType, true));

		StructType structType = DataTypes.createStructType(fields);
		DataStreamReader dataStreamReader = spark.readStream();
		
		// # Files to fecth
		dataStreamReader.option("maxFilesPerTrigger", 1);

		Dataset<Row> df = dataStreamReader
				.format("json")
				.schema(structType)
				.json("/Users/s0v00ao/file_input");

		// Introduced trigger
		StreamingQuery query = df.writeStream()
				.option("checkpointLocation", "/Users/s0v00ao/Desktop/Demo/checkpoint_file")
				.option("truncate", false)
				.outputMode("append")
				.format("console")
				.trigger(Trigger.ProcessingTime(10000))
				.start();
		  
		query.awaitTermination();
		
		
	}
}









/*
  try {
	            while (query.isActive()) {
	                try {
	                    if (query.lastProgress().numInputRows() <= 0) {
	                        query.stop();
	                    }
	                    else {
	                    	System.out.println(query.lastProgress().prettyJson());
	                    }
	                } catch (NullPointerException e) {
	                    // query will be null for some lastProgress(), Hence do nothing.
	                    // Since the query will be running on the main thread and
	                    // the query.progress() will be running on the child threads
	                    System.out.println("Awaiting for First Batch to complete!" + e.getMessage());
	                }
	                //Sleep the main thread at 25% configured batch interval
	                Thread.sleep(5000);
	            }
	            query.awaitTermination();
	        } catch (Exception e) {
	        	 System.out.println("Exception");
	        }
*/		
